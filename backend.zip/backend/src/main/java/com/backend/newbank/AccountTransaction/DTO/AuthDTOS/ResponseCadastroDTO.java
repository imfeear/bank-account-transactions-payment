package com.backend.newbank.AccountTransaction.DTO.AuthDTOS;

public record ResponseCadastroDTO(String message) {

}
