

-- Credit Card Status
INSERT INTO status (name, code) VALUES
                                    ('Blocked', 40),
                                    ('Inactive', 41),
                                    ('Active', 42),
                                    ('Canceled', 43),
                                    ('Expired',44);