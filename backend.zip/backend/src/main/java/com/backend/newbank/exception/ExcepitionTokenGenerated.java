package com.backend.newbank.exception;

public class ExcepitionTokenGenerated extends RuntimeException {
    public ExcepitionTokenGenerated(String message) {
        super(message);
    }
}
