package com.backend.newbank.AccountTransaction.DTO.AccountDTO;

import java.math.BigDecimal;

public record BalanceDetailsDTO(
    BigDecimal balance
) {}

