package com.backend.newbank.AccountTransaction.entity.Enum;

public enum Person_type {
    fisica,
    juridica
}
