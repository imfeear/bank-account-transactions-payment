package com.backend.newbank.Payment.DTO;

public record BarcodeDTO(String accountNumber, String agencyNumber, String value) {
}
