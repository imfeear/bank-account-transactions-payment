package com.backend.newbank.Payment.DTO;

import lombok.Data;

@Data
public class PaymentStateDTO {

    private Integer statusId;
    private Integer methodId;
}
